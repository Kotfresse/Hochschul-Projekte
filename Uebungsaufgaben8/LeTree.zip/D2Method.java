/**
 * D2Method
 */
public interface D2Method {
    public double compute(double x);
}
